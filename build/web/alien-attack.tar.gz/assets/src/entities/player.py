import pygame
import math
from settings import game_characters, screen_properties

IMAGE = game_characters["player"]
SCREEN_WIDTH = screen_properties["width"]
SCREEN_HEIGHT = screen_properties["height"]


class Player(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()

        self.image = pygame.image.load(IMAGE).convert_alpha()
        self.rect = self.image.get_rect(
            center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100)
        )
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = 20

        self.posX = float(self.rect.x)
        self.posY = float(self.rect.y)

    def update(self):
        mouseX, mouseY = pygame.mouse.get_pos()

        dirX = mouseX - self.posX
        dirY = mouseY - self.posY
        distance = math.hypot(dirX, dirY)

        if distance != 0:
            dirX /= distance
            dirY /= distance

        if distance > self.speed:
            self.posX += dirX * self.speed
            self.posY += dirY * self.speed
        else:
            self.posX = mouseX
            self.posY = mouseY

        self.rect.centerx = round(self.posX)
        self.rect.centery = round(self.posY)

        # Limitar movimiento a los bordes de la pantalla
        self.rect.clamp_ip(pygame.Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT))
